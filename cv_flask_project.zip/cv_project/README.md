# Sanjaya Kandel — CV Flask App
## Setup & Run Instructions

### 1. Install system dependencies (WeasyPrint needs these)

**Ubuntu / Debian (or WSL on Windows):**
```bash
sudo apt-get install -y python3-pip libpango-1.0-0 libpangoft2-1.0-0 libharfbuzz0b libffi-dev libjpeg-dev libopenjp2-7-dev libgdk-pixbuf2.0-0
```

**macOS:**
```bash
brew install pango libffi jpeg openjpeg
```

**Windows:** Use WSL2 (Ubuntu) — WeasyPrint does not work natively on Windows.

---

### 2. Install Python dependencies
```bash
pip install -r requirements.txt
```

---

### 3. Add your photo
Place your profile photo at:
```
static/images/professional.jpeg
```

---

### 4. Run the app
```bash
python app.py
```
Then open: **http://localhost:5000**

---

### 5. How download works
- Click the **Download** button in the bottom-right corner
- The button animates (Uiverse style)
- After ~3.8s, the browser calls `/download-pdf`
- Flask renders `cv_print.html` → WeasyPrint converts to PDF → browser downloads `Sanjaya_Kandel_CV.pdf`

---

### Project Structure
```
cv_project/
├── app.py                    ← Flask backend
├── requirements.txt
├── README.md
├── templates/
│   ├── cv.html               ← Interactive CV (with cursor, loading, animations)
│   └── cv_print.html         ← Clean print version (WeasyPrint renders this)
└── static/
    └── images/
        └── professional.jpeg ← Your photo goes here
```
