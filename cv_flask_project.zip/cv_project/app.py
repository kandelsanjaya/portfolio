from flask import Flask, render_template, make_response, send_file
from weasyprint import HTML, CSS
import io
import os

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('cv.html')

@app.route('/download-pdf')
def download_pdf():
    # Render the CV template (print version — no loading screen, no cursor)
    html_string = render_template('cv_print.html')

    # Convert HTML → PDF in memory
    base_url = os.path.abspath(os.path.dirname(__file__))
    pdf_bytes = HTML(
        string=html_string,
        base_url=base_url
    ).write_pdf()

    response = make_response(pdf_bytes)
    response.headers['Content-Type']        = 'application/pdf'
    response.headers['Content-Disposition'] = 'attachment; filename="Sanjaya_Kandel_CV.pdf"'
    return response

if __name__ == '__main__':
    app.run(debug=True, port=5000)
